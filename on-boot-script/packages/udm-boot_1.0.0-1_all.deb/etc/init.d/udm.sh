#!/bin/sh

ssh -o StrictHostKeyChecking=no root@127.0.1.1 '/mnt/data/on_boot.sh'

